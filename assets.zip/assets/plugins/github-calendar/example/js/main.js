GitHubCalendar(".calendar", "Dyoussef95", {
    responsive: true,
    tooltips: true
});
